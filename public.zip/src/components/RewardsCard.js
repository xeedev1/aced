import React from 'react';

const RewardsCard = ({ rewards, onClaim }) => {
  return (
    <div className="neo-card p-6">
      <h2 className="text-xl font-bold mb-6">Your Rewards</h2>
      <div className="flex justify-between items-center mb-4">
        <div>
          <div className="text-sm text-blue-400">Pending Rewards</div>
          <div className="text-2xl font-bold">{rewards}</div>
        </div>
        <button
          onClick={onClaim}
          className="bg-gray-800 hover:bg-gray-700 px-8 py-3 rounded-full transition-all duration-300"
        >
          Claim
        </button>
      </div>
      <div className="h-2 bg-blue-900/30 rounded-full overflow-hidden h-4">
        <div className="progress-bar h-full w-3/4 bg-gradient-to-r from-blue-600 to-[#00ffff] rounded-full"></div>
      </div>
    </div>
  );
};

export default RewardsCard;
