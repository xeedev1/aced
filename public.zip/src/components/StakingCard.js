import React from 'react';

const StakingCard = ({ balance, stakedAmount, setStakedAmount, onStake }) => {
  return (
    <div className="neo-card p-6">
      <h2 className="text-xl font-bold mb-6">Stake Your Tokens</h2>
      <div className="space-y-4">
        <div className="glass-panel p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-blue-400">Amount to Stake</span>
            <span className="text-sm">Balance: {balance}</span>
          </div>
          <div className="flex space-x-4">
            <input
              type="text"
              placeholder="0.0"
              value={stakedAmount}
              onChange={(e) => setStakedAmount(e.target.value)}
              className="input-field w-full"
            />
            <button
              onClick={() => setStakedAmount(balance.toString())}
              className="bg-gray-800 hover:bg-gray-700 px-8 py-3 rounded-full transition-all duration-300"
            >
              Max
            </button>
          </div>
        </div>
        <button
          onClick={onStake}
          className="bg-blue-600 hover:bg-blue-700 px-8 py-3 rounded-full transition-all duration-300 w-full py-3"
        >
          Stake Now
        </button>
      </div>
    </div>
  );
};

export default StakingCard;
